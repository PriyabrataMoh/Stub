package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {
	
	static WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
		
	}
	WebDriverWait wait;
	
	
	@FindBy (xpath = "//*[@class='flex-grow-1 tab-bus']")
	WebElement bus_icon;
	
	@FindBy (id = "txtOrigin")
	WebElement origin;
	
	@FindBy (id = "txtDestination")
	WebElement dest;
	
	@FindBy (id = "btnBusSearchNew")
	WebElement search;
	
	@FindBy (xpath = "//*[text()='Cameron Highlands']")
	WebElement island;
	
	
	
	public void login(String s, String d)
	{
		
		bus_icon.click();

		wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(origin));
		
		origin.click();
		origin.sendKeys(s);
		//island.click();
		
		dest.sendKeys(d);
		
		search.click();
	}
	
	public void Alert(String s, String d) throws InterruptedException
	{
		
		bus_icon.click();

		wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(origin));
		
		origin.clear();
		
		//island.click();
		
		dest.clear();
		Thread.sleep(5000);
		search.click();
		
	}
	
}

