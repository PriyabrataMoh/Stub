package testcase;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import Pages.LoginPage;
import utils.HelperClass;

public class tc_01 extends HelperClass{
	
	LoginPage page;
	
	@Test (priority=1)
	public void loginTest()
	{
		page = PageFactory.initElements(driver, LoginPage.class);
		
		page.login("Delhi","Mumbai");
	
				
	}
	
	@Test (priority=2)
	public void AlertTest() throws InterruptedException
	{
		page = PageFactory.initElements(driver, LoginPage.class);
		
		page.Alert("Delhi","Mumbai");
		
	}

}

