package utils;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import broswerFactory.BrowserFactory;

public class HelperClass {
	
	public static WebDriver driver;
	
	@BeforeSuite
	public void getURL()
	{
		driver = BrowserFactory.initDriver("chrome");
		driver.get("https://www.busonlineticket.com/booking/");
	
	}
	
	@AfterSuite
	public void CloseBrowser()
	{
		driver.quit();
	
	}
}
