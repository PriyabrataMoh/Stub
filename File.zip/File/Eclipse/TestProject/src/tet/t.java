package tet;

public class t {
	
	public static void main(String [] args)
	{
		System.out.println("testtttttt");
	}

}
