package StringProgram;

public class count_SUBSTRING_instring {
	
	String s = "abaaaa";
	String s1 = "aa";
	
	public static void main(String[] args) {
		
	}
	
}
