package StringProgram;

public class count_SpecialChar_instring {
	
	  public static void main(String[] args) {
	        String s = "He said, god is Great!";
	        int count = 0;
	        for (int i = 0; i < s.length(); i++) {
	            if (s.charAt(i) == ',' || s.charAt(i) == '&' || s.charAt(i) == '!') {
	                count++;
	            }
	        }
	        System.out.println("count---------" + count);
	    }

}
