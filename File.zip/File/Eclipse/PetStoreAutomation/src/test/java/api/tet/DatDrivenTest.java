package api.tet;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import api.endpoints.UserEndpoints;
import api.payload.User;
import api.utilities.DataProviders;
import io.restassured.response.Response;

public class DatDrivenTest {
	
	User userPayload;
	
	
	@Test(priority = 1, dataProvider = "Data", dataProviderClass = DataProviders.class)
	public void testPostUser(String userID, String userName, String Fname, String lName, String email,String pwd,String ph)
	{
		
		userPayload = new User();
		
		userPayload.setId(Integer.parseInt(userID));
		userPayload.setUsername(userName);
		userPayload.setFirstName(Fname);
		userPayload.setLastName(lName);
		userPayload.setEmail(email);
		userPayload.setPassword(pwd);
		userPayload.setPhone(ph);
		
		Response rs = UserEndpoints.createUser(userPayload);
		rs.then().log().all();
		
		AssertJUnit.assertEquals(rs.getStatusCode(), 200);
		
	}
	
	@Test(priority = 2, dataProvider = "UserNames", dataProviderClass = DataProviders.class)
	public void testGetUserByName(String user)
	{
		Response res = UserEndpoints.readUser(user) ;
		res.then().log().all();
		
		AssertJUnit.assertEquals(res.getStatusCode(), 200);
	}
	
}
	