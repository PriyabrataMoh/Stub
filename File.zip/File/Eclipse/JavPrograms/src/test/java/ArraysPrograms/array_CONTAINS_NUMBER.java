package ArraysPrograms;

import java.util.Scanner;

public class array_CONTAINS_NUMBER {
	
	public static boolean check(int[]a , int b)
	{
		
		for(int i =0;i<a.length;i++)
		{
			if(a[i]==b)
			{
				return true;
			}
		}
		return false;
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] a = new int[5];
		
		Scanner sc = new Scanner(System.in);
		
		for(int i =0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		
		System.out.println(check(a,5));

	}

}
