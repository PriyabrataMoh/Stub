package ArraysPrograms;

public class array_COUNT_SUMOF_NUMBER_GIVEN_NUMBER {
	
	public static void main(String [] args) {
        int a[] = {1, 2, 3, 4, 5};
        int sum = 5;

        int count = 0;

        for(int i =0;i<a.length;i++)
        {
            for(int j =0;j<a.length;j++)
            {
                if(a[i]+a[j]==sum && i!=j)
                {
                    count ++;
                    System.out.println(a[i]+"---------"+a[j]);
                }
            }
        }

        System.out.println(count);

    }

}
