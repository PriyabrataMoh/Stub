package ArraysPrograms;

public class LARGEST_SECONDL_SMALL_array {
	
	 public static void main(String[] args) {
	        int a[] = {5, 4, 8, 3, 1, 7};

	        
	        int large = a[0];
	        int sl = a[0];
	        int small=a[0];
	        
	        for(int i =0;i<a.length;i++)
	        {
	        	
	        	if(a[i]>large)
	        	{
	        		sl = large;
	        		large = a[i]; 
	        	}
	        	else if(a[i]>sl)
	        	{
	        		sl = a[i]; 
	        	}
	        	else if(a[i]<small)
	        	{
	        		small = a[i]; 
	        	}
	        	
	        }
	        
	        System.out.println("Largest------"+large+" Second Large-------"+sl+" smallest -------"+ small);
    	        
	        
	 }
}
