package ArraysPrograms;

import java.util.HashSet;
import java.util.Set;

public class PRINT_UNIQUE_array_SET {
	
	public static void main(String[] args)
    {
        int[] ar ={1,2,3,1,2,4,3,34};
        int size = ar.length;
        
        
     Set<Integer> s = new HashSet<>();   
        
     for(int i =0;i<ar.length;i++)
     {
    	 s.add(ar[i]);
     }
        
     for(Integer i : s)
     {
    	 System.out.println(i);
     }
        
    }

}
