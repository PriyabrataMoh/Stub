package ArraysPrograms;

public class PRINT_UNIQUE_array {
	
	public static void main(String[] args)
    {
        int[] ar ={1,2,3,1,2,4,3,34};
        int size = ar.length;

        for(int i=0;i<size;i++)
        {
            for(int j=i+1;j<size;j++)
            {
                if(ar[i]==ar[j])
                {
                    while(j<(size)-1)
                    {
                        ar[j]=ar[j+1];
                        j++;
                    }
                    size--;
                }

            }
        }

        System.out.println("size===="+size);
        for(int k =0;k<size;k++)
        {
            System.out.println(ar[k]);
        }
    }

}
