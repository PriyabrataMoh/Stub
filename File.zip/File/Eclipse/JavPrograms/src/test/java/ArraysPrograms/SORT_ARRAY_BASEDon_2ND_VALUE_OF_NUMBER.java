package ArraysPrograms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SORT_ARRAY_BASEDon_2ND_VALUE_OF_NUMBER {
	
	
	public static void main(String[] args)
	{
		Comparator<Integer> comp = new Comparator<Integer>() {
			
			@Override
			public int compare(Integer o1, Integer o2) {
				
				if(o1%10>o2%10) 
					return 1;
				else
					return -1;
				
			}
		};
		
		List<Integer> ls = new ArrayList<>();
		ls.add(45);
		ls.add(32);
		ls.add(47);
		ls.add(21);
		ls.add(18);

		Collections.sort(ls,comp);
		System.out.println(ls);
		
		
	}

}
