package ArraysPrograms;

import java.util.Scanner;

public class array_CONTAINS_STRING {

	public static boolean check(String[]a , String b)
	{
		
		for(int i =0;i<a.length;i++)
		{
			if(a[i].equals(b))
			{
				return true;
			}
		}
		return false;
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] a = new String[5];
		
		Scanner sc = new Scanner(System.in);
		
		for(int i =0;i<a.length;i++)
		{
			a[i]=sc.next();
		}
		
		System.out.println(check(a,"hi"));

	}

}
