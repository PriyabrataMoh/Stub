package ArraysPrograms;

public class array_DUPLICATE_ELEMENT {
	
	public static void main(String [] args) {
		
		int ar []={1,2,3,4,5,6,7,8,2,3};
		boolean flag;
		
		
		for(int i =0;i<ar.length;i++)
		{
			flag = false;
			
			for(int j =i+1;j<ar.length;j++)
			{
				if(ar[i]==ar[j] && i!=j)
				{
					flag = true;
				}
			}
			
			if(flag)
			{
				System.out.println(ar[i]);
			}
		}
		
		
	}
	

}
