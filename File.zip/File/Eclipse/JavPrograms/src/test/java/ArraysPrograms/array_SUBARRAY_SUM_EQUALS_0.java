package ArraysPrograms;

public class array_SUBARRAY_SUM_EQUALS_0 {
	
	public static boolean foundSubArray(int[] ar)
	{
		
		for(int i =0;i<ar.length;i++)
		{
			int sum = ar[i];
			if(sum==0)
					return true;
		
			for(int j =i+1;j<ar.length;j++)
			{
				int onesum = sum+ar[j];
				if(onesum==0)
					return true;
			}
		
		}
		return false;
	}
	
	public static void main(String[] args)
	{
		
		int ar[]= {-4,3,4};
		
		if(foundSubArray(ar))
		{
			System.out.println("Found array with sum 0");
		}
		else
		{
			System.out.println("Not Found array with sum 0");

		}
		
	}

}
