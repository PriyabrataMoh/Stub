package CollectionPrograms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SORT_MAP_VALUES {
	
	 public static void main(String [] args)
	    {
	        Map<Integer,String > map = new HashMap();
	        map.put(11,"hi");
	        map.put(23,"abc");
	        map.put(9,"zxy");
	        map.put(77,"hgd");
	        map.put(34,"aad");
	        
	        
	        Set<Map.Entry<Integer, String>> set = map.entrySet();
	        List<Map.Entry<Integer, String>> lst = new ArrayList(set);
	        
	        Collections.sort(lst,new Comparator<Map.Entry<Integer, String>>() {
	        	
	        	public int compare(Map.Entry<Integer, String> o1,Map.Entry<Integer, String> o2)
	        	{
	        		return o1.getValue().compareTo(o2.getValue());
	        	}
			});

	        lst.forEach(s->{System.out.println(s.getKey()+"\t"+s.getValue());});
	        
	    }

}