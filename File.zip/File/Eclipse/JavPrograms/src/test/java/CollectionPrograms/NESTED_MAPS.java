package CollectionPrograms;

import java.util.HashMap;
import java.util.Map;

public class NESTED_MAPS {
	
	public static void main(String []args) {

	
	Map<String, Map<String, String>> employeeMap = new HashMap();

    Map<String, String> addressMap = new HashMap();
    addressMap.put("Permanent", "Florida");
    addressMap.put("Postal", "Canada");

    Map<String, String> addressMap1 = new HashMap<>();
    addressMap1.put("Permanent1", "Florida1");
    addressMap1.put("Postal1", "Canada1");

    Map<String, String> addressMap2 = new HashMap<>();
    addressMap2.put("Permanent2", "Florida2");
    addressMap2.put("Postal2", "Canada2");

    employeeMap.put("Alex", addressMap);
    employeeMap.put("roy", addressMap1);
    employeeMap.put("kin", addressMap2);

    for (Map.Entry<String, Map<String, String>> empMap : employeeMap.entrySet()) {
        Map<String, String> addMap = empMap.getValue();
        System.out.println(empMap.getKey() + " :: " + empMap.getValue());

        // Iterate InnerMap
        for (Map.Entry<String, String> addressSet : addMap.entrySet()) {
            System.out.println(addressSet.getKey() + " :: " + addressSet.getValue());
        }
    }
}


}
