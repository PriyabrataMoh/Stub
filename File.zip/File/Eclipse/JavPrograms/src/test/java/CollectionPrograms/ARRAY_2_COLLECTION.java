package CollectionPrograms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;

public class ARRAY_2_COLLECTION {
	
	 public static void main(String[] args) {
	        Integer[] ar = {2, 3, 4, 1, 5, 8, 7};
	        
	  List<Integer> lst = Arrays.asList(ar);
	  TreeSet<Integer> tr = new TreeSet<>(lst);
	  
	  System.out.println("smallest--- "+ tr.pollFirst());
      System.out.println("largest--- "+ tr.pollLast());	      
	        
	 }

}
