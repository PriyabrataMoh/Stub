package StringPrograms;

public class count_NUMBERofCHAR_instring {
	
	static String s ="javabest";
	
    static int count =0;

    public static void main(String[] args)
    {
        for(int i =0;i<s.length();i++)
        {
        	if(s.charAt(i)=='a') {
        		count++;
        	}
        }
        
        System.out.println(count);
        
        	
    }
}
