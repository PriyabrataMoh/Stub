package StringPrograms;

public class MAX_MIN_CHARACTER_instring2 {
	
	public static void main(String[] args)
    {
        String s ="hhi my name is ram";
        int freq[] = new int[s.length()];
        char minChar = s.charAt(0),maxChar=s.charAt(0);
        int min,max;

        char [] ch = s.toCharArray();

        for(int i=0;i<s.length();i++)
        {
            freq[i]=1;
            for(int j=i+1;j<s.length();j++)
            {
                if(ch[i]==ch[j] && ch[i]!=' ' && ch[i]!='0')
                {
                    freq[i]++;
                    ch[j]='0';
                }
            }

        }

        min = max = freq[0];
        for(int i=0;i<freq.length;i++)
        {
            if(min>freq[i] && freq[i]!='0'){
                min = freq[i];
                minChar = ch[i];
            }

            if(max<freq[i])
            {
                max = freq[i];
                maxChar = ch[i];
            }
        }

        System.out.println("min character--------"+ minChar);
        System.out.println("max character--------"+ maxChar);

    }

}
