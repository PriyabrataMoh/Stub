package StringPrograms;

public class REVERSE_WORD_instring {
	
	public static void main(String[] args) {
        String s = "hi good day";
        String org = "";

        String s1[] = s.split(" ");

        for(int i=s1.length-1;i>=0;i--)
        {
            String s2 = s1[i];
            org = org+s2+ " ";
        }

        System.out.println(org);

    }

}
