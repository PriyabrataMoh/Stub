package StringPrograms;

public class REMOVE_CHARACTER_1st_2nd_instring {
	
	public static void main(String[] args) {
        String s = "hi my name is ram hi";
        String s1 = "hi";

        char [] c = s.toCharArray();
        char[]c1= s1.toCharArray();

        for(int i=0;i<c.length;i++)
        {
            for(int j=0;j<c1.length;j++)
            {
                if(c[i]==c1[j] && c[i]!=' ')
                {
                    c[i]=' ';
                }
            }
        }

        for(int k=0;k<c.length;k++)
        {
            System.out.println(c[k]);
        }
	}
}
