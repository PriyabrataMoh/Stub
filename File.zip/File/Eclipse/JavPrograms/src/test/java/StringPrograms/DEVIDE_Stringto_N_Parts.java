package StringPrograms;

public class DEVIDE_Stringto_N_Parts {
	
	public static void main(String[] args)
	{
		
		String s = "aaabbbccc";
		int n = 3;
		
		char[] c = s.toCharArray();
		int len = s.length();
		int devide = len/n;
		int temp=0;
		
		String[] st = new String[n];
		
		if(len%n != 0)
		{
			System.out.println("String can not be devided to equal parts");
		}
		else
		{
			for(int i =0;i<len;i=i+devide)
			{
				String part = s.substring(i,i+devide);
				st[temp] = part;
				temp++;
			}
			
			System.out.println("Equal parts of the string are: ");
			
			for(String s1: st)
			{
				System.out.println(s1);
			}
		}
		
	}

}
