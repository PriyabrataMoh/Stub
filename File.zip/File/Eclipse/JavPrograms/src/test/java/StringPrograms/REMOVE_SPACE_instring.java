package StringPrograms;

public class REMOVE_SPACE_instring {
	
	public static void main(String[] args) {

        String s = "hi my name is hello";

        String s1 = s.replaceAll("\\s+","");
        System.out.println(s1);

    }

}
