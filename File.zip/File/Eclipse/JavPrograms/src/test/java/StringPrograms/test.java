package StringPrograms;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;

import javax.sound.midi.Soundbank;

public class test {
			
	 public static int lengthOfLongestSubstring(String s) {
	        // HashSet to store the characters in the current window
	        HashSet<Character> set = new HashSet<>();
	        int n = s.length();
	        int i = 0, j = 0, maxLength = 0;
	        
	        // Use two pointers i and j to define the window
	        while (i < n && j < n) {
	            // If character s[j] is not in the set, add it and move j pointer
	            if (!set.contains(s.charAt(j))) {
	                set.add(s.charAt(j++));
	                maxLength = Math.max(maxLength, j - i);
	            } 
	            // If character s[j] is already in the set, remove character s[i] and move i pointer
	            else {
	                set.remove(s.charAt(i++));
	            }
	        }
	        
	        return maxLength;
	    }
	    
	    public static void main(String[] args) {
	        String s = "abcabcbb";
	        System.out.println("The length of the longest substring without repeating characters is: " + lengthOfLongestSubstring(s));
	    }
}

