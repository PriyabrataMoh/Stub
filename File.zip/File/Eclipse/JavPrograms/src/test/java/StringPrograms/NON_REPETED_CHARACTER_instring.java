package StringPrograms;

public class NON_REPETED_CHARACTER_instring {
	
	public static void main(String[] args) {
        String s = "dghdgj";

        boolean t ;

        for(int i =0;i<s.length();i++)
        {
            t = false;
            for(int j=0;j<s.length();j++)
            {
                if(s.charAt(i)==s.charAt(j) && i!=j){

                t = true;
                break;
            }
        }
            if(!t)
            {
                System.out.println("Unique charachter is --------------- "+s.charAt(i));
            }
        }
    }

}
