package StringPrograms;

import java.util.ArrayList;

public class count_SUBSTRING_instring {
	
	public static void main(String[] args) {

	String s = "abaaaa";
	String s1 = "aa";
	
	int index = 0;
	int count =0;
	
	ArrayList ar = new ArrayList();
		
		while((index = s.indexOf(s1,index))!=-1)
		{
			count++;
			ar.add(index);
			index++;
			
		}
		
		System.out.println("Total count------"+ count);
		System.out.println("index of substring------"+ ar);

		
	}
	
}
