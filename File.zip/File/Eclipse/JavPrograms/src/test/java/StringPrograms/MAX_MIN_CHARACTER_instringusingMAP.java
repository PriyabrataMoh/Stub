package StringPrograms;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MAX_MIN_CHARACTER_instringusingMAP {
	
	public static void main(String[] args) {
        String s = "hello everyoneh";

        HashMap<Character, Integer> map = new HashMap<>();
        char[] ch = s.toCharArray();

        for (Character c : ch) {
            if (map.containsKey(c)) {
                map.put(c, map.get(c) + 1);
            } else {
                map.put(c, 1);
            }
        }

        int maxValueInMap=(Collections.max(map.values()));  // This will return max value in the HashMap
        int minValueInMap=(Collections.min(map.values()));  // This will return min value in the HashMap

        for (Map.Entry<Character, Integer> entry : map.entrySet()) {  // Iterate through HashMap
            if (entry.getValue() == maxValueInMap) {
                System.out.println("MAX VALUE ------"+entry.getKey());     // Print the key with max value
            }
            if(entry.getValue() == minValueInMap) {
                System.out.println("MIN VALUE ------"+entry.getKey());
            }
        }

    }
	
}
