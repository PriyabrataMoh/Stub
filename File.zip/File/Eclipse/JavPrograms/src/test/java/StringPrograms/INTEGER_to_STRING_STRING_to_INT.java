package StringPrograms;

public class INTEGER_to_STRING_STRING_to_INT {
	
	
	public static void main(String[] args) {
		
		int i = 10;
		
		String s = String.valueOf(i);
		
		int a = Integer.parseInt(s);
		
		System.out.println(s);
		System.out.println(a);

	}

}
