package StringPrograms;

public class find_SUBSET_instring {

	public static void main(String [] args)
	
	{
		String s = "FUN";
		int temp =0;
		
		int len = s.length();
		
		
		int comb = len*(len+1)/2;
		String[] s1 = new String[comb];
		
		for(int i =0;i<s.length();i++)
		{			
			for(int j =i;j<s.length();j++)
			{
				
				s1[temp] = s.substring(i,j+1);
				temp++;
				
			}
			
		}
		for(String s2:s1)
		{
			System.out.println(s2);
		}
		
	}

}

