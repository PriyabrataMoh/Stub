package StringPrograms;

import java.util.Arrays;

public class ANAGRAM_instring {
	
	public static void main(String[] args) {
        String a = "qwer";
        String b = "wqre";

        char[] c = a.toCharArray();
        char[] c1 = b.toCharArray();

        if(a.length()!=b.length())
        {
            System.out.println("not anagram");
        }
        else
        {
            Arrays.sort(c);
            Arrays.sort(c1);

            if(Arrays.equals(c,c1))
            {
                System.out.println("anagram");
            }
            else {
                System.out.println("not anagarma");
            }
        }

    }

}
