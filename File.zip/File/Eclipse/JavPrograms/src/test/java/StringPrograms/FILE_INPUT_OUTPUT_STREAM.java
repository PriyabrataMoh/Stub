package StringPrograms;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FILE_INPUT_OUTPUT_STREAM {
	
	public static void main(String[] args) throws IOException {
		
		     FileInputStream fi = new FileInputStream(new File("/Users/priyabrata.mohanty/Desktop/DailyExecutionDebugScreen/Text.txt"));
	         
		     int i =0;
		     while((i=fi.read())!=-1)
		     {
		    	 System.out.println((char)i);
		     }
		     fi.close();
		     
		     

	        FileOutputStream bw = new FileOutputStream(new File("/Users/priyabrata.mohanty/Desktop/DailyExecutionDebugScreen/Text.txt"));
	        String s = "goodmorning";
	        byte[] s1 = s.getBytes();
	        bw.write(s1);
	        bw.close();

	     }

}
