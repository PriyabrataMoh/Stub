package StringPrograms;

public class DUPLICATE_CHAR_instring {
	
	public static void main(String[] args) {
        String s = "hi my name is ram";

        for(int i =0;i<s.length();i++)
        {
            for (int j =i+1;j<s.length();j++)
            {
                if (s.charAt(i)==s.charAt(j) && s.charAt(i)!=' ')
                {
                    System.out.println(s.charAt(i));
                    break;
                }
            }
        }
    }

}
