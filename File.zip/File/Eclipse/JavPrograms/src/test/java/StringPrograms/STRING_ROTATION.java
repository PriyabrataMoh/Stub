package StringPrograms;

public class STRING_ROTATION {
	
	public static void main(String[] args) {
		
		
		String s = "abcd";
		String s1 ="fbhj";
		
		if(s.length()!=s1.length())
        {
            System.out.println("no rotation");
        }
		else
		{
			
			s = s.concat(s);
			
			if(s.indexOf(s1)!=-1)
			{
				System.out.println("rotation");
			}
			else
			{
				System.out.println("not rotation");
			}
		}
		
		
	}

}
