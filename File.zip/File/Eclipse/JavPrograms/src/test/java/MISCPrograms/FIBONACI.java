package MISCPrograms;

public class FIBONACI {
	
	static int n1,n3=0;
	static int n2 = 1;
	
	public static void fibo(int n)
	{
		if(n>0)
		{
			n3=n1+n2;
			n1=n2;
			n2=n3;
			System.out.print(" "+n3);
		
		fibo(n-1);
		}
		
	}
	
	public static void main(String[] args)
	{
		int num =15;
		System.out.print (n1 +" " + n2);
		fibo(num-2);
		
	}

}
