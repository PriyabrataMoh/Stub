package MISCPrograms;

public class COMBINATION_A_B_C_N {
	
	static int countIntegralSolutions(int n)
    {
        return ((n + 1) * (n + 2)) / 2;

    }

    // Driver code
    public static void main (String[] args)
    {
        int n = 3;
        System.out.println ( countIntegralSolutions(n));

    }

}
