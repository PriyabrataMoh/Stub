package org.LetteCode;

import java.util.HashMap;
import java.util.HashSet;

public class LENGTH_OF_LONGEST_SUBSTRING {

        public static int lengthOfLongestSubstring(String s) {
            // HashMap to store the characters and their most recent positions
            HashMap<Character, Integer> map = new HashMap<>();
            int n = s.length();
            int maxLength = 0;

            // Start of the current window
            int start = 0;

            for (int i = 0; i < n; i++) {
                char currentChar = s.charAt(i);

                // If the character is already in the map and its index is within the current window
                if (map.containsKey(currentChar) && map.get(currentChar) >= start) {
                    // Move the start to the right of the duplicate character
                    start = map.get(currentChar) + 1;
                }

                // Update the character's most recent position
                map.put(currentChar, i);

                // Calculate the maximum length of the substring
                maxLength = Math.max(maxLength, i - start + 1);
            }

            return maxLength;
        }

        public static void main(String[] args) {
            String s = "abcabcbbf";
            System.out.println("The length of the longest substring without repeating characters is: " + lengthOfLongestSubstring(s));
        }
}
