package org.MISC.programs;


import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class JSON_RESPONSE {

    public static void main(String[] args) throws IOException {
        String urlString = "https://dummyjson.com/products/1"; // Replace with your API URL

            // Create a URL object
            URL url = new URL(urlString);

            // Open a connection to the URL
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            // Set the request method to GET
            conn.setRequestMethod("GET");

            // Set request headers if needed
            conn.setRequestProperty("Accept", "application/json");

            // Get the input stream of the connection
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            // Read the response line by line and store it in a StringBuilder
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }

            // Close the input stream
            in.close();

            // Convert the response to a string
            String jsonResponse = response.toString();


            //till getting reponse I already wrote the code
        String res = "{\n" +
                "  \"users\": [\n" +
                "    {\n" +
                "      \"firstname\": \"John\",\n" +
                "      \"lastname\": \"Doe\",\n" +
                "      \"email\": \"john.doe@gmail.com\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"firstname\": \"Jane\",\n" +
                "      \"lastname\": \"Smith\",\n" +
                "      \"email\": \"jane.smith@gmail.com\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"firstname\": \"Alice\",\n" +
                "      \"lastname\": \"Johnson\",\n" +
                "      \"email\": \"alice.johnson@gmail.com\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"firstname\": \"Bob\",\n" +
                "      \"lastname\": \"Brown\",\n" +
                "      \"email\": \"bob.brown2@gmail.com\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"firstname\": \"Invalid\",\n" +
                "      \"lastname\": \"Email\",\n" +
                "      \"email\": \"invalid.email@example.com\"\n" +
                "    }\n" +
                "  ]\n" +
                "}";

        //coder pad was throwing compile exception
        JSONObject ob = new JSONObject(res);
        JSONArray jsPendingTest = ob.getJSONArray("users");
        int length = jsPendingTest.length();

        for(int i =0;i<length;i++) {
            JSONObject firstSport = jsPendingTest.getJSONObject(i);

            String email = firstSport.getString("email");
            String name = firstSport.getString("firstname").toLowerCase();
            String Lname = firstSport.getString("lastname").toLowerCase();

            if(email.equals(name+"."+Lname+"@gmail.com"))
            {
                System.out.println("correct for "+email);
            }
            else
            {
                System.out.println("not correct for "+email);

            }
        }
    }
}
