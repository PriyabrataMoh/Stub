package org.MISC.programs;

public class PRIME_NUMBER {

    public static void checkPrime(int n)
    {
        int flag=0,m=0;
        m = n/2;

        if(n==0||n==1)
        {
            System.out.println("not prime");
        }
        else
        {
            for(int i=2;i<m;i++)
            {
                if(n%i==0)
                {
                    System.out.println("not prime");
                    flag =1;break;
                }
            }

            if(flag==0)
            {
                System.out.println("prime");
            }
        }
    }

    public static void main(String[] args)
    {
        checkPrime(23);
    }

}
