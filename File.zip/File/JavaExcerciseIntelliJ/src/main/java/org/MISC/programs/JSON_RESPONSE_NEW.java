package org.MISC.programs;


import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class JSON_RESPONSE_NEW {

    public static void main(String[] args) throws IOException, InterruptedException {
        String urlString = "https://dummyjson.com/products?sortBy=title&order=asc"; // Replace with your API URL

            // Create a URL object
           /* URL url = new URL(urlString);

            // Open a connection to the URL
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            // Set the request method to GET
            conn.setRequestMethod("GET");

            // Set request headers if needed
            conn.setRequestProperty("Accept", "application/json");

            // Get the input stream of the connection
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            // Read the response line by line and store it in a StringBuilder
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }

            // Close the input stream
            in.close();

            // Convert the response to a string
            String jsonResponse = response.toString();*/

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(urlString))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        String resp = response.body();


            //till getting reponse I already wrote the code

        //coder pad was throwing compile exception
        JSONObject ob = new JSONObject(resp);
        JSONArray jsPendingTest = ob.getJSONArray("products");
        int length = jsPendingTest.length();

        for(int i =0;i<length;i++) {
            JSONObject firstSport = jsPendingTest.getJSONObject(i);

            String thumbnail = firstSport.getString("thumbnail");
            String shipInfo = firstSport.getString("shippingInformation").toLowerCase();
            int id = firstSport.getInt("id");

            System.out.println("thumbNail: "+thumbnail+" ----  ship info: "+ shipInfo +" ------ ID: "+id);


        }
    }
}
