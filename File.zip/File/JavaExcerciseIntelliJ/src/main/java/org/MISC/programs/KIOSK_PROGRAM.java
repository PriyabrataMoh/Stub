package org.MISC.programs;

public class KIOSK_PROGRAM {

    private static final int[] BILL_DENOMINATION = {20,10};
    private static final int[] CENT_DENOMINATION = {5,2,1};

    public static void main(String[] args) {
        int itemCost = 23;
        int moneyInsertered = 100;
        int change = moneyInsertered-itemCost;

        int[] bills = CalculateBill(BILL_DENOMINATION,change);
        int [] cents = CalculateCent(CENT_DENOMINATION,change-sumArray(bills,BILL_DENOMINATION));


        for(int i =0;i<bills.length;i++)
        {
            if(bills[i]>0)
            System.out.println("$"+BILL_DENOMINATION[i]+"--------"+bills[i]);
        }

        for(int i =0;i<cents.length;i++)
        {
            if(cents[i]>0)
                System.out.println("$"+CENT_DENOMINATION[i]+"--------"+cents[i]);
        }
    }

    private static int[] CalculateBill(int[] billDenomination, int change){
            int[] bill = new int[billDenomination.length];
            for(int i =0;i<bill.length;i++)
            {
                bill[i] = change/billDenomination[i];
                change=change%billDenomination[i];
            }

            return bill;
        }

    private static int[] CalculateCent(int[] centDenomination, int change) {
        int[] cent = new int[centDenomination.length];
        for(int i =0;i<cent.length;i++)
        {
            cent[i] = change/centDenomination[i];
            change=change%centDenomination[i];
        }

        return cent;
    }

    private static int sumArray(int[] bills, int[] billDenomination) {
        int sum =0;

        for(int i =0;i<bills.length;i++)
        {
            sum += bills[i]*billDenomination[i];
        }
        return sum;

    }

}
