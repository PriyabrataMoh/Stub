package org.ARRAYS.prgrams;

public class LARGEST_SecondL_Smallest_Array1 {

    public static void main(String[] args) {
        int a[] = {5, 4, 8, 3, 1, 7};
        int tmp = 0;

        for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {
                if (a[i] > a[j]) {
                    tmp = a[i];
                    a[i] = a[j];
                    a[j] = tmp;
                }
            }
        }

        for(int k=0;k<a.length;k++)
        {
            System.out.println(a[k]);
        }
        System.out.println("Largest------"+a[a.length-1]+" Second Large-------"+a[a.length-2]+" smallest -------"+ a[0]);
    }
}
