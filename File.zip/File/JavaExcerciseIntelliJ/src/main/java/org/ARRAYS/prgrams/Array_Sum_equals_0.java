package org.ARRAYS.prgrams;

public class Array_Sum_equals_0 {

    public static boolean subArrayExits(int arr[])
    {
        for(int i =0;i<arr.length;i++)
        {
            int sum = arr[i];
            if (sum==0)
                return true;
            for(int k =i+1;k<arr.length;k++)
            {
                int Onesum=sum+arr[k];
                if(Onesum==0)
                    return true;

            }
        }
        return false;
    }


    public static void main(String[] args)
    {
        int ar[] ={-4,3,4};
        if(subArrayExits(ar))
            System.out.println("Found a Subarray with 0 sum");
        else
            System.out.println("No Subarray with 0 sum");

    }
}
