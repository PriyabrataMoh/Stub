package org.ARRAYS.prgrams;

public class MISSING_NUMBER_array {

    public static void main(String[] args) {
        int a[] = {1,2,3,5,6,7};

        int l = a.length;
        int total =(l+1)*(l+2)/2;


        for(int i =0;i<a.length;i++)
        {
            total = total-a[i];
        }

        System.out.println(total);
    }
}
