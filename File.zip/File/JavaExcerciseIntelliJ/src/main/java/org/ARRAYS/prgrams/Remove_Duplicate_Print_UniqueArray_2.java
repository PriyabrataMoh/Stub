package org.ARRAYS.prgrams;

public class Remove_Duplicate_Print_UniqueArray_2 {

    public static void main(String[] args)
    {

        int [] ar = {1, 1, 2, 2, 3, 4, 5};

        int ar1[] = new int[ar.length];

        for(int i=0;i<ar.length;i++)
        {
            ar1[i]=1;
            for(int j=i+1;j<ar.length;j++)
            {
                if(ar[i]==ar[j] && ar[i]!=0)
                {
                    ar1[i]++;
                    ar[j]=0;
                }
            }
        }

        for(int k=0;k<ar.length;k++)
        {
            System.out.println(ar[k]);
        }
    }
}
