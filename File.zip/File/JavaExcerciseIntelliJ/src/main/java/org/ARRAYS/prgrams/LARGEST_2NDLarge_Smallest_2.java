package org.ARRAYS.prgrams;

public class LARGEST_2NDLarge_Smallest_2 {

    public static void main(String[] args) {
        int a[] = {10,3, 4, 8, 5, 1, 7};

        int large =Integer.MIN_VALUE;
        int secondL=Integer.MIN_VALUE;

        for(int i =0;i<a.length;i++)
        {
            if(a[i]>large)
            {
                secondL = large;
                large = a[i];
            }

            else if(a[i]>secondL && a[i] != large)
            {
                secondL = a[i];
            }

        }

        System.out.println("Largest------"+large+" Second Large-------"+secondL);
    }

}
