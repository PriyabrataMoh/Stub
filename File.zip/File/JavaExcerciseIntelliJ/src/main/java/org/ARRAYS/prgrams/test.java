package org.ARRAYS.prgrams;

import java.util.*;

public class test {

    public static void main(String[] args) {

        Comparator<Integer> comp = new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                if(o1%10>o2%10)
                {
                    return 1;
                }
                else {
                    return -1;
                }
            }
        };

        List<Integer> ar = new ArrayList<>();
        ar.add(45);
        ar.add(36);
        ar.add(91);
        ar.add(52);

        Collections.sort(ar, comp);
        System.out.println(ar);


    }

}