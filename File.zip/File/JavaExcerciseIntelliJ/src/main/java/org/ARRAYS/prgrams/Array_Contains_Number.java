package org.ARRAYS.prgrams;

import java.util.Scanner;

public class Array_Contains_Number {

    public static boolean check(int[] a , int num)
    {
        for(int i =0;i<a.length;i++)
        {
            if(a[i]==num)
            {
                return true;
            }
        }
        return false;

    }

    public static void main(String[] args)
    {

        int[] n = new int [3];

        Scanner scn = new Scanner(System.in);

        System.out.println("enetre numbers");
        for(int i =0;i< n.length;i++)
        {
            n[i]= scn.nextInt();
        }

        int x = 20;
        System.out.println(check(n,x));

    }
}
