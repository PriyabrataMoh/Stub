package org.ARRAYS.prgrams;

import java.util.Scanner;

public class Array_Contains_String {

    public static boolean check(String[] a , String num)
    {
        for(int i =0;i<a.length;i++)
        {
            if((a[i]).equals(num))
            {
                return true;
            }
        }
        return false;

    }

    public static void main(String[] args)
    {

        String[] n = new String [3];

        Scanner scn = new Scanner(System.in);

        System.out.println("enetre numbers");
        for(int i =0;i< n.length;i++)
        {
            n[i]= scn.next();
        }

        String x = "hi";
        System.out.println(check(n,x));

    }
}
