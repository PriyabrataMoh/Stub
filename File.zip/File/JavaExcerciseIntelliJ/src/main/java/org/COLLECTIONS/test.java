package org.COLLECTIONS;

import java.util.*;

public class test {

    public static void main(String[] args)
    {
        Map<Integer,String> map = new HashMap<Integer,String >();

        map.put(3,"hg");
        map.put(7,"gg");
        map.put(1,"as");
        map.put(9,"aa");

        Set<Map.Entry<Integer,String>> set = map.entrySet();
        List<Map.Entry<Integer,String>> lst = new ArrayList<>(set);

        Collections.sort(lst, new Comparator<Map.Entry<Integer, String>>() {
            @Override
            public int compare(Map.Entry<Integer, String> o1, Map.Entry<Integer, String> o2) {
                return o1.getValue().compareTo(o2.getValue());
            }
        });

        lst.forEach(s->{
            System.out.printf(s.getKey()+"-----"+s.getValue());
        });


    }


}
