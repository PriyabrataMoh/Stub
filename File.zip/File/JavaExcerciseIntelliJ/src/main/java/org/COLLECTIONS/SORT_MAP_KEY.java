package org.COLLECTIONS;

import java.util.*;

public class SORT_MAP_KEY {

    public static void main(String [] args)
    {
        Map<Integer,String > map = new HashMap<Integer,String >();
        map.put(11,"hi");
        map.put(23,"abc");
        map.put(9,"zxy");
        map.put(77,"hgd");
        map.put(34,"aad");

        Set<Map.Entry<Integer,String>> entry =map.entrySet();

        List<Map.Entry<Integer,String>> list = new ArrayList(entry);

        Collections.sort(list, new Comparator<Map.Entry<Integer, String>>() {
            @Override
            public int compare(Map.Entry<Integer, String> o1, Map.Entry<Integer, String> o2) {
                return o1.getKey().compareTo(o2.getKey());
            }
        });

       list.forEach(s->{System.out.println(s.getKey()+"\t"+s.getValue());});
            
        }
    }
