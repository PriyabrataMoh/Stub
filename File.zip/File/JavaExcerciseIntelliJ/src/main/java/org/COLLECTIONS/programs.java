package org.COLLECTIONS;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class programs {

   /* public static void main(String [] args)
    {

        Map<String,Object> map = new HashMap<String ,Object>();
        map.put("a",2);
        map.put("b",3);
        map.put("d",4);

        Map<String,Object> nestedMap = new HashMap<String ,Object>();
        nestedMap.put("a",1);
        nestedMap.put("b",3);
        nestedMap.put("2",nestedMap);

       // Map<String,Object> modify = getModifyMap(map);



      *//* {a:2,b:3,d:4,e:{a:1,b:3}}
        A:2
        {a:2,b:3,d:4,e:{a:1,b:3}}*//**

    }

    public static Map<String ,Integer> getModifyMap(Map<String , Object> input)
    {

        for(Map.Entry<String ,Object> map : input.entrySet())
        {
            if(map.getValue() instanceof  )
        }
    }
*/
}
