package org.COLLECTIONS;

import java.security.PublicKey;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class ARRAY_2_COLLECTION {

    public static void main(String[] args) {
        Integer[] ar = {10,2, 3, 4, 1, 5, 8, 7};

        List<Integer> lst = Arrays.asList(ar);
        TreeSet<Integer> s = new TreeSet(lst);

        System.out.println("smallest--- "+ s.pollFirst());
        System.out.println("largest--- "+ s.pollLast());

    }
}
