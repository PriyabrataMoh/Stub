package org.STRINGSprograms;

public class Count_Number_Of_Character_In_String
{

    static String s ="javabest";
    static int count =0;

    public static void main(String[] args)
    {
        for(int i=0;i<s.length();i++)
        {
            if (s.charAt(i)=='b')
            {
                count++;
            }
        }
        System.out.println(count);
    }
}
