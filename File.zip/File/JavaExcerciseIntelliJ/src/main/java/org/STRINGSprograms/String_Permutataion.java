package org.STRINGSprograms;

public class String_Permutataion {

    public static void main(String[] args)
    {
        String s ="ABC";
        int len = s.length();
        System.out.println("all the permutataion of string");
        generatePermutataion(s,0,len);
    }

    public static String swapString(String a,int i,int j)
    {
        char[] b = a.toCharArray();
        char ch;
        ch =b[i];
        b[i]=b[j];
        b[j]=ch;
        return String.valueOf(b);

    }
    public static void generatePermutataion(String str,int start, int end)
    {
        if(start==end-1)
        {
            System.out.println(str);
        }
        else
        {
            for(int i =0;i<end;i++)
            {
                str = swapString(str,start,i);
                generatePermutataion(str,start+1,end);
                str = swapString(str,start,i);

            }
        }
    }
}
