package org.STRINGSprograms;

import java.util.Stack;

public class Valid_Paranthesis_String_1 {
     static boolean isValidate(String str) {
            char[] ch = str.toCharArray();
            Stack<Character> st = new Stack<>();
            for (char chNew : ch) {
                if (chNew == '(') {
                    st.push(')');
                } else if (chNew == '{') {
                    st.push('}');
                } else if (chNew == '[') {
                    st.push(']');
                } else if (st.isEmpty() || st.pop() != chNew) {
                    return false;
                }
            }
            return st.isEmpty(); // Check if the stack is empty at the end
        }

        public static void main(String[] args) {
            String ss = "[()]{}{[()()]()";
            //String ss ="()}";
            System.out.println(isValidate(ss));
        }
}
