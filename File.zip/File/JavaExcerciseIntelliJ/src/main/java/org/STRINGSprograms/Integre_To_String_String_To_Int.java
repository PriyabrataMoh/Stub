package org.STRINGSprograms;

public class Integre_To_String_String_To_Int {

    public static void main(String [] args) {
        int i = 10;

        String s = String.valueOf(i);

        int a = Integer.parseInt(s);

        System.out.println(s);

        System.out.println(a);

    }
}
