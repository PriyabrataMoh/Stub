package org.STRINGSprograms;

import java.util.HashMap;
import java.util.Map;

public class ANAGRAM_WITHOUT_SORT {
        public static void main(String[] args) {
            String str1 = "listen";
            String str2 = "silent";

            boolean isAnagram = areAnagrams(str1, str2);
            System.out.println("Are the strings \"" + str1 + "\" and \"" + str2 + "\" anagrams? " + isAnagram);
        }

        public static boolean areAnagrams(String s1, String s2) {
            if (s1.length() != s2.length()) {
                return false;
            }

            Map<Character, Integer> charCountMap = new HashMap<>();

            // Count the frequency of each character in the first string
            for (char c : s1.toCharArray()) {
                charCountMap.put(c, charCountMap.getOrDefault(c, 0) + 1);
            }

            // Decrease the frequency based on the second string
            for (char c : s2.toCharArray()) {
                if (!charCountMap.containsKey(c)) {
                    return false;
                }
                charCountMap.put(c, charCountMap.get(c) - 1);
                if (charCountMap.get(c) == 0) {
                    charCountMap.remove(c);
                }
            }

            // If the map is empty, then both strings are anagrams
            return charCountMap.isEmpty();
        }

}
