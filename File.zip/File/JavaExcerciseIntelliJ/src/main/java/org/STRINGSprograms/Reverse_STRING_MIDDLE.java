package org.STRINGSprograms;

import java.util.Stack;

public class Reverse_STRING_MIDDLE {

    public static void main(String[] args)
    {
        String input ="abcdef";
        Stack st = new Stack();

        String output = "";
        int mid = input.length()/2;


        for(int i =0;i<mid;i++)
        {
            st.push(input.charAt(i));
        }
        while(!st.isEmpty())
        {
            output=output+st.pop();
        }
        for(int i =mid;i<input.length();i++)
        {
            st.push(input.charAt(i));
        }
        while(!st.isEmpty())
        {
            output=output+st.pop();
        }

        System.out.println(output);
    }
}
