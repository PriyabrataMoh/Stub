package org.STRINGSprograms;

public class Reverse_Word_Character_in_String {

    public static void main(String[] args) {
        String s = "hi good day";
        String org = "";

        String s1[]=s.split(" ");

        for(int i = s1.length-1;i>=0;i--)
        {
            String word = s1[i];
            String wr = "";

            for(int j = word.length()-1;j>=0;j--)
            {
                wr = wr+word.charAt(j);
            }

            org = org+wr+" ";
        }
        System.out.println(org);

    }
}
