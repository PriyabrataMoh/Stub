package org.STRINGSprograms;

import java.util.ArrayList;

public class COUNT_SUBSTRING_in_STRING {

    public static void main(String[] args) {
        String s = "ababaaaa";
        String s1 = "aa";

        int count = 0;
        int index = 0;
        ArrayList ar = new ArrayList();
        while((index=s.indexOf(s1,index))!=-1)
        {
            count++;
            ar.add(index);
            index++;

        }
        System.out.println("Total count------ "+count);
        System.out.println("index of substring---- "+ar);


    }
}
