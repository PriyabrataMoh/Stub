package org.STRINGSprograms;

public class Duplicate_Word_In_String {

    public static void main(String[] args) {
        String s = "hi my name is ram hi is";
        String[] s1 = s.split(" ");

        for(int i =0;i<s1.length;i++)
        {
            for (int j =i+1;j<s1.length;j++)
            {
                if (s1[i].equals(s1[j]))
                {
                    System.out.println(s1[j]);
                    break;
                }
            }
        }
    }
}
