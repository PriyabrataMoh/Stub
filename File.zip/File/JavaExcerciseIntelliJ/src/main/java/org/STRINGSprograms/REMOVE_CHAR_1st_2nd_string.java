package org.STRINGSprograms;

import java.util.HashSet;

public class REMOVE_CHAR_1st_2nd_string {

    public static void main(String[] args) {
        String s = "hi my name is ram";
        String s1 = "hi";

        char[] c = s.toCharArray();
        char[] c1 = s1.toCharArray();

        // Use a set for faster lookup
        HashSet<Character> set = new HashSet<>();
        for (char ch : c1) {
            if (ch != ' ') {
                set.add(ch);
            }
        }

        for (int i = 0; i < c.length; i++) {
            if (set.contains(c[i]) && c[i] != ' ') {
                c[i] = ' ';
            }
        }

        // Print characters in a single line
        for (char ch : c) {
            System.out.print(ch);
        }
        System.out.println(); // To move to the next line after printing the result
    }
    }
