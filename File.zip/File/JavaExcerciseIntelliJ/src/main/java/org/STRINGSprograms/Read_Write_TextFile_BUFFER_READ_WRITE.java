package org.STRINGSprograms;

import java.io.*;

public class Read_Write_TextFile_BUFFER_READ_WRITE {

        public static void main(String[] args) throws IOException {
            BufferedReader br = new BufferedReader(new FileReader("/Users/priyabrata.mohanty/Desktop/DailyExecutionDebugScreen/Text.txt"));
            int i = 0;
            while ((i = br.read()) != -1) {
                System.out.print((char) i);
            }
            br.close();

           BufferedWriter bw = new BufferedWriter(new FileWriter("/Users/priyabrata.mohanty/Desktop/DailyExecutionDebugScreen/Text.txt",true));
            String s ="Hello World";
            bw.write(s);
            bw.close();

        }

    /*Read String From Textfile --- String output
    public static void main(String[] args) throws IOException {
        BufferedReader bf = new BufferedReader(new FileReader("/Users/priyabrata.mohanty/Desktop/DailyExecutionDebugScreen/Text.txt"));
        String i =null;
        while ((i=bf.readLine())!=null){

            String st = i;
            System.out.println(st);
        }

        bf.close();
*/

}
