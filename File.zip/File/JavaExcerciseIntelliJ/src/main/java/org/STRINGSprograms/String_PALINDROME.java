package org.STRINGSprograms;

public class String_PALINDROME {

    public static void main(String[] args) {
        String s = "NOON";
        String org = "";
        for (int i =s.length()-1;i>=0;i--)
        {
            org = org + s.charAt(i);
        }
        if(s.equals(org))
        {
            System.out.println("Prlindrome");
        }
        else {
            System.out.println("not palindrome");

        }

    }
}