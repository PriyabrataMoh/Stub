package org.STRINGSprograms;

import java.io.*;
import java.util.*;

public class test {

    static String s = null;
    static int maxtries = 3;

        public static boolean RetryToDivertSuccess () {
            boolean b = false;
                for (int i = 0; i < maxtries; i++) {
                    try{
                    if (s.length()==1) {
                        b = true;
                        break;
                    } else {
                        continue;
                    }
                }
                    catch (Exception ex) {
                        b = false;
                    }
            }
            return b;
        }

    public static void main(String[] args) {
        System.out.println(RetryToDivertSuccess());
    }
}



