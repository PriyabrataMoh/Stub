package org.STRINGSprograms;

public class Maximun_And_Minimun_Character_Occurance_In_String {

    public static void main(String[] args) {
        String s = "hhi my name is ram";
        int[] freq = new int[s.length()];
        char minChar = s.charAt(0), maxChar = s.charAt(0);
        int min, max;

        char[] ch = s.toCharArray();

        for (int i = 0; i < s.length(); i++) {
            freq[i] = 1;
            for (int j = i + 1; j < s.length(); j++) {
                if (ch[i] == ch[j] && ch[i] != ' ' && ch[j] != '0') {
                    freq[i]++;
                    ch[j] = '0'; // Mark this character as processed
                }
            }
        }

        min = max = freq[0];
        for (int i = 0; i < freq.length; i++) {
            if (ch[i] != '0' && ch[i] != ' ') { // Skip already processed characters and spaces
                if (min > freq[i]) {
                    min = freq[i];
                    minChar = ch[i];
                }

                if (max < freq[i]) {
                    max = freq[i];
                    maxChar = ch[i];
                }
            }
        }

        System.out.println("Minimum occurring character: " + minChar);
        System.out.println("Maximum occurring character: " + maxChar);
    }
}
