package org.STRINGSprograms;

public class Lower_To_Upper_CaseString {

    public static void main(String[] args) {
        String s = "GoodMorning";

        StringBuffer bf = new StringBuffer(s);
        for(int i =0;i<s.length();i++)
        {
            if(Character.isLowerCase(s.charAt(i)))
            {
                bf.setCharAt(i,Character.toUpperCase(s.charAt(i)));
            }
            else if(Character.isUpperCase(s.charAt(i)))
            {
                bf.setCharAt(i,Character.toLowerCase(s.charAt(i)));
            }
        }
        System.out.println(bf.toString());

    }

}
