package org.STRINGSprograms;

import java.util.HashSet;

public class Duplicate_Character_In_String {


    public static void main(String[] args) {
        String s = "hi my name is ram";
        HashSet<Character> printedChars = new HashSet<>();

        for(int i =0;i<s.length();i++)
        {
            for (int j =i+1;j<s.length();j++)
            {
                if (s.charAt(i)==s.charAt(j) && s.charAt(i)!=' ' && !printedChars.contains(s.charAt(i)))
                {
                    System.out.println(s.charAt(i));
                    printedChars.add(s.charAt(i));
                    break;
                }
            }
        }
    }
}
