package org.STRINGSprograms;

import java.util.HashMap;
import java.util.Map;

public class OCCURANCE_Of_Character_In_String
{
    public static void main(String[] args)
    {
        String s = "hello everyone";

        HashMap<Character,Integer> map = new HashMap<>();
        char[] ch = s.toCharArray();

        for (Character c:ch) {
            if(map.containsKey(c))
            {
                map.put(c,map.get(c)+1);
            }
            else
            {
                map.put(c,1);
            }
        }

        for(Map.Entry<Character,Integer> ent : map.entrySet())
        {
            if(!ent.getKey().equals(' ')){
                System.out.println(ent.getKey()+"----------"+ent.getValue());

            }
        }
    }


}
