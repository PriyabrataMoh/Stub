package org.STRINGSprograms;

public class Devide_String_To_N_Parts {

    public static void main(String[] args)
    {
        String s ="aaabbbccc";
        int n =3;

        char[] c = s.toCharArray();
        int temp =0;
        int len = s.length();
        int devide = len/n;

        String [] st = new String[n];

        if(len % n !=0)
        {
            System.out.println("String can not be devided");
        }
        else{

            for(int i=0;i<len;i= i+devide)
            {
                String part = s.substring(i,i+devide);
                st[temp] = part;
                temp++;
            }
            System.out.println("equal parts of given string are");
            for(int i=0;i<st.length;i++)
            {
                System.out.println(st[i]);

            }
        }
    }
}
