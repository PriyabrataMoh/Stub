package org.STRINGSprograms;

public class String_Permutataion_New {

    public static void permute(String s , String s1)
    {
        if(s.length()==0)
        {
            System.out.println(s1+" ");
            return;
        }

        for(int i=0;i<s.length();i++)
        {
            char c = s.charAt(i);

            String new1 = s.substring(0,i)+s.substring(i+1);
            permute(new1,s1+c);
        }

    }

    public static void main(String[] args)
    {
        String s ="ABC";
        permute(s,"");

    }
}
