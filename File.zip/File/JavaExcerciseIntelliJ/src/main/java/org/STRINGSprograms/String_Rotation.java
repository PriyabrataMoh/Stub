package org.STRINGSprograms;

public class String_Rotation {

    public static void main (String[] args) {
        String a = "abcd";
        String b = "fghj";

        if(a.length()!=b.length())
        {
            System.out.println("no rot");
        }
        else {
            a = a.concat(a);

            if(a.indexOf(b)!=-1)
            {
                System.out.println("rotataion");
            }
            else
            {
                System.out.println("No rot");
            }
        }


    }
}
