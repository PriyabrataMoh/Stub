package org.STRINGSprograms;

public class Longest_Plaindrome_InSubString {

    static void printSub(String st, int low, int high) {
        for (int i = low; i <= high; i++) // Changed to <= to include the last character
            System.out.print(st.charAt(i));
        System.out.println();
    }

    static int longestPalSubString(String s) {
        int len = s.length();
        int maxLength = 1, start = 0;

        for (int i = 0; i < s.length(); i++) {
            for (int j = i; j < s.length(); j++) {
                int flag = 1;

                for (int k = 0; k < (j - i + 1) / 2; k++)
                    if (s.charAt(i + k) != s.charAt(j - k))
                        flag = 0;

                if (flag != 0 && (j - i + 1) > maxLength) {
                    start = i;
                    maxLength = j - i + 1;
                }
            }
        }
        System.out.println("Longest palindromic substring is: ");
        printSub(s, start, start + maxLength - 1);
        return maxLength;
    }

    public static void main(String[] args) {
        String s = "hiihhj";
        System.out.print("\nLength is " + longestPalSubString(s));
    }
}
