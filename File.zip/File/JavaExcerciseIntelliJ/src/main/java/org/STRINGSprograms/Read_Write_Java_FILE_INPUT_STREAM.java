package org.STRINGSprograms;

import java.io.*;

public class Read_Write_Java_FILE_INPUT_STREAM {

    public static void main(String[] args) throws IOException {
        FileInputStream fi = new FileInputStream("/Users/priyabrata.mohanty/Desktop/DailyExecutionDebugScreen/Text.txt");
        int i = 0;
        while ((i = fi.read()) != -1) {
            System.out.print((char) i);
        }
        fi.close();

    FileOutputStream fo = new FileOutputStream("/Users/priyabrata.mohanty/Desktop/DailyExecutionDebugScreen/Text.txt",true);
    String s ="Hello World";
    byte[] b = s.getBytes();
    fo.write(b);
    fo.close();

    }
}
