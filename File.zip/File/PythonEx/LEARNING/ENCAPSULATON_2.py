class Person():

    def __init__(self, name, age,gender):
        self.__name = name
        self.__age=age
        self.__gender = gender

    @property
    def Name(self):
        return self.__name

    @Name.setter
    def Name(self,value): # if we will not have the @name.setter , it will throw error method with same name
                          # but different parameter , Method overloading does not work in python
        self.__name=value

p = Person("bob",21,'M')
print(p.Name)

#https://www.youtube.com/watch?v=FDdfGFhY9Ms
#https://www.youtube.com/watch?v=_0SGomLTW0k