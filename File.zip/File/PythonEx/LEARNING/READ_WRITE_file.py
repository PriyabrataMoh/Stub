
with open("/Users/priyabrata.mohanty/Desktop/pythonEx2.txt",'a') as file:
    file.write('welcome to python')

# 'w' mode as argument will write the file but also it remove the Old content
# 'a' or -append will not remove any previous chanracter of file but append it with old code
# to write a new line send '\n'' to the write string

    file.write('\nI love python')
    file.close()

# READING FILE:
# problem statement : read the file with multiple line and save the file with word count in the end of file

file_input=open("/Users/priyabrata.mohanty/Desktop/pythonEx2.txt",'r')
file_out=open("/Users/priyabrata.mohanty/Desktop/pythonEx3.txt",'w')

for line in file_input: # iterate through each line
    numberWord = line.split(' ') # return an array
    print(len(numberWord)) # length of each array
    file_out.write(' wordCount '+ str(len(numberWord))+' '+line)

file_input.close()
file_out.close()

################# FILE MODES ##############

# r = open file in read only . throw error if not present
# w = open file in write only . Create if not present
# r+ = open file for both read and write
# w+ = Open file for read and write . If file not present create new one if present ovverwrite. Means previos data is lost completely
# a = Open file in append mode . All the write will be appended
# data = f.read() - read entire file
# data = f.readline()- read line by line
# data = f.read(5) - read only 5 character
# the 'with' statement you dont have to close the file explicitly in the end

######## DELETE FILE##########
#import os
#os.remove(file path)