class Person:
    def __init__(self, name=None, age=None):
        if name is not None and age is not None:
            self.name = name
            self.age = age
        else:
            self.name = "Unknown"
            self.age = 0

    @classmethod
    def from_birth_year(cls, name, birth_year):
        return cls(name, 2024 - birth_year)


# Using default constructor
person1 = Person("Alice", 30)
print(person1.name, person1.age)  # Output: Alice 30

# Using alternative constructor
person2 = Person.from_birth_year("Bob", 1990)
print(person2.name, person2.age)  # Output: Bob 34