class course():

    def __init__(self):
        self.name = "python"
        self.__tech ="inharitence" #private class memeber defined as __


    def print_course(self):
        return self.name +" : "+ self.__tech

    def get__tech(self):
        return self.__tech

    def set__tech(self,t):
        self.__tech = t


c= course()
print(c.name)
#print(c.__tech) # it will throw attibute error
#print(c._course__tech) # it will print the private variable
                       # syntax: _classname__variablename

c.set__tech("polymorphism")
print(c.get__tech())

#https://www.youtube.com/watch?v=FDdfGFhY9Ms