import time

def time_count(func):
    def wrapper(*args,**kwargs):
        start = time.time()
        result = func(*args,**kwargs)
        end = time.time()
        print(func.__name__+ " took " + str((end-start)*1000))
        #return result
    return wrapper

@time_count
def square(nums):
    result=[]
    for i in nums:
        result.append(i*i)
    return result

@time_count
def qube(nums):
    result = []
    for i in nums:
        result.append(i*i*i)
    return result

@time_count
def greet():
    print("hello world")

a = range(1,1000)
square(a)
qube(a)
greet()

#https://www.youtube.com/watch?v=IVWZxr0kOyI&list=PLeo1K3hjS3uv5U-Lmlnucd7gqF-3ehIh0&index=28
#https://www.youtube.com/watch?v=PTBZ674EsvI
#https://www.youtube.com/watch?v=yNzxXZfkLUA

# A decorator is essentially a function that takes another function as an argument and returns a new function with enhanced functionality.
#
# Decorators are often used in scenarios such as logging, authentication and memorization, allowing us to add additional functionality to existing functions or methods in a clean, reusable way.