class Father:
    def skills(self):
        print("gardening")
    def office(self):
        print ("going office")

class Mother:
    def skills(self):
        print("Cooking")

class Child(Father,Mother): # multiple inheritance

    def skills(self):
        Father.skills(self) # call father method
        Mother.skills(self) # call mother method
        print("gardening")

c= Child()
c.skills()
c.office()