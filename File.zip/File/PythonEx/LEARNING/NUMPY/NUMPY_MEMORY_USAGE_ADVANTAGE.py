import numpy as np
import time

size = 1000000

l1 = range(size)
l2 = range(size)


a1 = np.arange(size)
a2 = np.arange(size)

#normal list
start = time.time()
result = [(x+y) for x,y in zip(l1,l2)]
print("Using normal list the size is :", (time.time()-start)*1000)


#using numpy
start = time.time()
result = a1 + a2
print("numpy took: ", (time.time()-start)*1000 )

#https://www.youtube.com/watch?v=rN0TREj8G7U&list=PLeo1K3hjS3uv5U-Lmlnucd7gqF-3ehIh0&index=39