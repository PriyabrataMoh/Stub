import numpy as np

#one dimensonal array
a1 = np.array([1,2,3,4])
a2 = np.array([5,6,7,8])

print(a1+a2)

print(a1-a2)

print(a1*a2)

print(a1/a2)

# https://www.youtube.com/watch?v=a8aDcLk4vRc&list=PLeo1K3hjS3uv5U-Lmlnucd7gqF-3ehIh0&index=40

#two dimensonal array
a1 = np.array([[1,2],[3,4]])
a2 = np.array([[5,6],[7,8]])


print(a1+a2)

print(a1-a2)

print(a1*a2)

print(a1/a2)