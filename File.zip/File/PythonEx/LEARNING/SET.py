lst = [1,2,3,4,5,1,2,3]
st = set(lst)

print(st)
st.add(9)
print(st)

fs = frozenset(lst)
#fs.add(7) # frozen set cannt add element
print(fs)

x ={'b','c','a'}
y={'a','h','g'}

print(x|y) # union
print(x&y) #intercection
print(x-y) #not common

print(x<y) # x is subset of y

x ={'h','g'} # add h & g so it comes subset of Y
print(x<y) # x is subset of y

#https://www.youtube.com/watch?v=RD6JionMlXM&list=PLeo1K3hjS3uv5U-Lmlnucd7gqF-3ehIh0&index=27