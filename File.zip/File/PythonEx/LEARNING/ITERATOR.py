class TVRemote():

    def __init__(self):
        self.channels=["HBO","ESPN","SONY","STAR"]
        self.index = -1

    def __iter__(self):
        return self

    def __reversed__(self):
        return self

    def __next__(self):
        self.index+=1
        try:
            if self.index == len(self.channels):
                raise StopIteration
        except IndexError as e :
            pass
        return self.channels[self.index]

tv = TVRemote()
itr = iter(tv)
print(next(itr))
print(next(itr))
print(next(itr))
print(next(itr))

cars = ["nano", "swift", "bolero", "BMW"]
# reversing the list
reversed_cars = list(reversed(cars))
#printing the list
print(reversed_cars)

#https://www.youtube.com/watch?v=ffFRuB03qLE&list=PLeo1K3hjS3uv5U-Lmlnucd7gqF-3ehIh0&index=23
#https://www.youtube.com/watch?v=jTYiNjvnHZY