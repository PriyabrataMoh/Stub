class Test:

    def __init__(self,n,o): ##All classes have a function called __init__(), which is always executed when the class is being initiated.

        self.name= n
        self.occupation= o

    def do_work(self):
        if self.occupation == 'actor':
            print(self.name," works in movies ")
        if self.occupation == 'tenis':
            print(self.name," Plays tenis ")

    def speak(self):
        print(self.name,' Hey!!! How are You')

tom = Test('Tom Cruise','actor')
tom.do_work()

sara = Test('Sarapova','tenis')
sara.do_work()
sara.speak()