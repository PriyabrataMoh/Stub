import threading
import time

start = time.time()
def do_something(seconds):
    print(f'sleeping {seconds} seconds....')
    time.sleep(1)
    print("done sleeping")

t1=[]

for i in range(10):
    th = threading.Thread(target=do_something,args=(1.5,))
    th.start()
    t1.append(th)

for thr in t1:
    thr.join()

print("tike taken ",time.time()-start)