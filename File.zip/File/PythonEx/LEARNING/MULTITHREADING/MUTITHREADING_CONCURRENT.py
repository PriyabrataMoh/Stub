import concurrent.futures
import time

start = time.time()
def do_something(seconds):
    print(f'sleppeing {seconds} seconds....')
    time.sleep(seconds)
    return f"done sleeping {seconds}"

with concurrent.futures.ThreadPoolExecutor() as executor:
    sec=[5,4,3,2,1]

    result = executor.map(do_something,sec)

    for res in result:
        print(res)

print("tike taken ",time.time()-start)

#https://www.youtube.com/watch?v=IEEhzQoKtQU