import time
import threading

print_lock = threading.Lock()
# In this code:
#
# We create a print_lock object using threading.Lock().
# We use the with print_lock: statement to ensure that each print statement is executed without interruption by other threads.
# This ensures that the output from one thread's print statement does not get mixed with the output from another thread, and
# each line of output appears correctly on a new line.

def cal_squre(num):
    for i in num:
        time.sleep(0.2)
        with print_lock:
            print("squre of num: ",i*i)

def cal_cube(num):
    for i in num:
        time.sleep(0.2)
        with print_lock:
            print("cube of num: ",i*i*i)

start = time.time()
arr = [2,3,4,5]

t1 = threading.Thread(target=cal_squre,args=(arr,))
t2 = threading.Thread(target=cal_cube,args=(arr,))

t1.start()
t2.start()

t1.join() # wait till thread t1 completes
t2.join() # wait till t2 thread completes

print('total time taken ',(time.time()-start))


#Ex2

class Hello(threading.Thread):
    def run(self):
        for i in range(200):
            print("hello")
            time.sleep(1)

class Hi(threading.Thread):
    def run(self):
        for i in range(200):
            print("hi")
            time.sleep(1)

t1 = Hello()
t2= Hi()

t1.start()
t2.start()

t1.join()
t2.join()

print("bye") # this is being print by the Main thread which is availabe alway , and it will print after the above thread complete as join statmenet


#https://www.youtube.com/watch?v=PJ4t2U15ACo&list=PLeo1K3hjS3uv5U-Lmlnucd7gqF-3ehIh0&index=29