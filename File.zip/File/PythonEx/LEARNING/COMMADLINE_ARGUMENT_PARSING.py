import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("number1",help="first number")
    parser.add_argument("number2",help="second number")
    parser.add_argument("operation",help="operation")

    args = parser.parse_args()

    print(args.number1)
    print(args.number2)
    print(args.operation)

    num1 = int(args.number1)
    num2 = int(args.number2)

    if args.operation == "add":
        result = num1+num2
    elif args.operation == "minus":
        result = num1-num2
    elif args.operation == "multiply":
        result = num1*num2

print(result)

#https://www.youtube.com/watch?v=OxpBMNalsDM&list=PLeo1K3hjS3uv5U-Lmlnucd7gqF-3ehIh0&index=27
