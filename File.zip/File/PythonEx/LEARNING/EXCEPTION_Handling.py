class Accident(Exception):

    def __init__(self,msg):
        self.msg = msg

    def print_exception(self):
        print("user defined exception:" , self.msg)


try :
    raise Accident(" crash b/w two cars")
except Accident as e:
    e.print_exception()

class finallyUse():
    def process_file(self):

        try:
            f = open("c:\\test\\wrongpath.txt")
            x = 1/0

        except FileNotFoundError as e:
             print(('inside except'))
        finally:
            print("in finally")

#https://www.youtube.com/watch?v=WIqX3kDxDKE&list=PLeo1K3hjS3uv5U-Lmlnucd7gqF-3ehIh0&index=22
#https://www.youtube.com/watch?v=ZUqGMDppEDs