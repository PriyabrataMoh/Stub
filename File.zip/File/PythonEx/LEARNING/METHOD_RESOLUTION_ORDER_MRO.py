class A:
    name = "ram"
    def __init__(self):
        print("in A")
    def work(self):
        print("programmer")

class B():
    def __init__(self):
        print("in B")
    def work(self):
        print("Painter")

class C(A,B): # A in left , B in right
    def __init__(self):
        super().__init__()
        #if there is a conlict for either constructor or method it will Print the class present in Left .
        # which is A here
        # if you want to call B , the write class C(B,A)
        print("in C")

c = C()
c.work() # it will print method of A as A is in left

#https://www.youtube.com/watch?v=6P-P879BcHQ