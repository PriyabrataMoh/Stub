from abc import ABC,abstractmethod

class Computer(ABC):

    @abstractmethod
    def process(self):
        pass # if doing nothing in method mark as "pass" else it will return "none"


class Laptop(Computer):
    def process(self):
        print ("my laptop")

class whiteboard:
    def write(self,com):
        print("its writing")
        com.process()

class Programmer:
    def work(self):
        print("solving bug")
       # com.process() ------- this will throw error . To make this method invoke need to inherit from abstract class Like
       # class Programer(Computer): Like mentioned above

#com = Computer() # runtim error as Abstract class obj cannt be created

com1 = Laptop()
com1.process();

board = whiteboard()
board.write(com1)

#wen inheriting from abstract class , the abstract method must be override

#https://www.youtube.com/watch?v=UDmJGvM-OUw
#https://www.youtube.com/watch?v=wySW_E4XsvE