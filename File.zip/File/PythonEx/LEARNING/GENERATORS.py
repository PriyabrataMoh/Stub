import random
import time

name = ["ram","shyam","hari","govind"]
major=["math","physics","arts","science"]

def people_list(num_people):
    result=[]
    for i in range (num_people):
        person={
            "id": i,
            'name':random.choice(name),
            'major': random.choice(major)
        }
        result.append(person)
    return result

def people_Generator(num_people):
    for i in range (num_people):
        person={
            "id", i,
            'name',random.choice(name),
            'major', random.choice(major)
        }
        yield person # value on the fly generator

#this is for list , but it consume lot of memory
#people =people_list(100000)
#for i in people:
#    print(i)


#this is for generator , it consume very less memory as it doe not store
# in memory , it fetch runtime
people =people_Generator(100000)
print(next(people))
print(next(people))
print(next(people))



#https://www.youtube.com/watch?v=bD05uGo_sVI
#https://www.youtube.com/watch?v=ixd-u3pmsUc
#https://www.youtube.com/watch?v=ixd-u3pmsUc

# A generator is simply a function which returns an object on which you can call next, such that for
# every call it returns some value, until it raises a StopIteration exception, signaling that all values have been generated.
# Such an object is called an iterator.