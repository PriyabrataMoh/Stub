import multiprocessing
import concurrent.futures


def square(numbers):
    for i in numbers:
        print("square:-----",str(i*i))


def qube(numbers):
    for i in numbers:
        print("qube:-------",str(i*i*i))

if __name__=='__main__': #maindatory to define for multi process . This is the entry point of code
    lst =[2,3,4,5,6]
    mp1 = multiprocessing.Process(target=square,args=(lst,) )
    mp2 = multiprocessing.Process(target=qube,args=(lst,) )

    mp1.start()
    mp2.start()


#https://www.youtube.com/watch?v=Lu5LrKh1Zno
#https://www.youtube.com/watch?v=zGe-9LfnAaA

#whith concurent features
# with concurrent.futures.ProcessPoolExecutor() as executor:
#     sec=[5,4,3,2,1]
#
#     result = executor.map(qube,sec)
#
#     for res in result:
#         print(res)

#https://www.youtube.com/watch?v=fKl2JW_qrso&t=1s

