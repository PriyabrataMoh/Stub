import multiprocessing

def calSq(number,q):

    for n in number:
        q.put(n*n)


if __name__=="__main__":
    numbers =[2,3,4,5]
    q = multiprocessing.Queue() # accesing vaaribale outside process by queue
    p = multiprocessing.Process(target=calSq, args=(numbers,q))

    p.start()
    p.join()

    while q.empty() is False:
        print(q.get())

#print("outside the function: "+ str(result)) # this will return none as the variable is
# valid only inside the process method


