import multiprocessing

result =[] # global variable

def calSq(number,result,val):
    val.value = 5.6
    for idx,n in enumerate(number):
        result[idx]= n*n
    #print("inside the function :"+ str(result)) # this will print result as its inside process


if __name__=="__main__":
    numbers =[2,3,4,5]
    result = multiprocessing.Array('i',4) # accesing vaaribale outside process by array
    val = multiprocessing.Value('d',55.3) # accesing by value
    p = multiprocessing.Process(target=calSq, args=(numbers,result,val))

    p.start()
    p.join()

    #print("outside the function: "+ str(result)) # this will return none as the variable is valid only inside the process method

    print(result[:])
    print(val.value)


#https://www.youtube.com/watch?v=uWbSc84he2Q