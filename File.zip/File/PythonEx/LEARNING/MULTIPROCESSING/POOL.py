import multiprocessing


#The multiprocessing module in Python allows you to create processes,
#thereby enabling parallel execution of tasks. One of the useful features of this module is the Pool class,
#which provides a convenient means of parallelizing the execution of a function across multiple input values,
#distributing the input data across processes (data parallelism).
from multiprocessing import Pool
import time

def square(num):
    sum = 0
    for i in range(1000):
        sum += num * num
    return sum

if __name__ == '__main__':
    # Using pool
    t1 = time.time()
    p = Pool()
    #p = Pool(processes=3) # this is a argument where you can assign the number of process . Its optional though

    result = p.map(square, range(100000))
    p.close()
    p.join()
    print("Time taken using pool: ", time.time() - t1)

    # Not using pool
    t2 = time.time()
    result1 = []
    for x in range(100000):
        result1.append(square(x))
    print("Time taken without pool: ", time.time() - t2)

#https://www.youtube.com/watch?v=_1ZwkCY9wxk&list=PLeo1K3hjS3uv5U-Lmlnucd7gqF-3ehIh0&index=34