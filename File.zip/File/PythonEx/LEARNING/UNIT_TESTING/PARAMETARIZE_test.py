import mathlib
import pytest

@pytest.mark.parametrize("input,output",
                         [
                             (5,25),
                             (4,15),
                             (10,100)
                         ]
                         )
def test_multiply(input,output):
    result = mathlib.cal_square(input)
    assert result == output