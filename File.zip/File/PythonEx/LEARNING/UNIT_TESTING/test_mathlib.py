import mathlib

def test_cal_total():
    total=mathlib.cal_total(5,6)
    assert total==11

def test_cal_multiply():
    total=mathlib.cal_multiply(5,6)
    assert total==30