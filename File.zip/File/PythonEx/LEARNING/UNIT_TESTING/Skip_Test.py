import sys

import mathlib
import pytest

@pytest.mark.skipif(sys.version_info > (3,5), reason = "version mismatch")
def test_addition():
    total=mathlib.cal_total(5,6)
    assert total == 11


def test_multiplication():
    total = mathlib.cal_multiply(5, 6)
    assert total == 30



#to run the test open the directory and run python3 -m pytest "Skip_Test.py" in terminal