import pytest

@pytest.mark.windows  # custom markers , you can use any marker instead of windows
def test_windows1():
    assert True

@pytest.mark.windows
def test_windows2():
    assert True

@pytest.mark.mac
def test_mac1():
    assert True

@pytest.mark.mac
def test_mac2():
    assert True

# to run this python3 -m pytest -m "windows" , here windows is the name of the marker