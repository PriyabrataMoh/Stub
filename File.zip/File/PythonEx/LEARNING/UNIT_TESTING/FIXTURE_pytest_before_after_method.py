import pytest

@pytest.fixture(scope="module") # only run once in module level not individual test level
def before():
    print("before test")
    yield
    print("after test") # this is after test

def test_1(before):
    print("in test 1")

def test_2(before):
    print("in test 2")

# to run the test python3 -m pytest "FIXTURE_pytest_before_after_method.py" -v -s