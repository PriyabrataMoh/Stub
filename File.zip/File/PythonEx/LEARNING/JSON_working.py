import json

book={}
book['tom']={
    'name':'tom',
    'adress':'HSR',
    'phone':12345
}
book['john']={
    'name':'jon',
    'adress':'BDA',
    'phone':7894
}

st = json.dumps(book)   # this dump the dictonary as json format , but store as String
print(st)

#write the above string to file
# write the string to a local file
with open("/Users/priyabrata.mohanty/Desktop/pythonEx_1.txt",'w') as file:
    file.write(st)
    file.close()

# read file from location and store as String
file_open = open("/Users/priyabrata.mohanty/Desktop/pythonEx_1.txt",'r')
readSt = file_open.read();
file.close()
print(readSt)

# read a string and load it as Json and store as a Dictionary
outBook = json.loads(readSt)

print(outBook['john']['adress']) # print the adress of John

for values in outBook: # print all values in dictionary
    print(outBook[values])