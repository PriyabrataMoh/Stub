import zope.interface


class MyInterface(zope.interface.Interface):
    x = zope.interface.Attribute("foo")

    def method1(self, x):
        pass

    def method2(self):
        pass


print(type(MyInterface))
print(MyInterface.__module__)
print(MyInterface.__name__)

# get attribute
x = MyInterface['x']
print(x)
print(type(x))

# interfaces are not necessary in Python. This is because Python has proper multiple inheritance,
# and also ducktyping, which means that the places where you must have interfaces in Java,
# you don't have to have them in Python.