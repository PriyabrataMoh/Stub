class Vehichle:

    def general_use(self):
        print(" general transport")

class Car(Vehichle):

    wheel = 0;

    def __init__(self):
        print(("I'm car'"))
        self.wheel = 4

    def speific_usgae(self):
        print("Specific use car")
        print(self.wheel)


class Motorcycle(Vehichle):

    wheel = 0;

    def __init__(self):
        print(("I'm Motorcycle'"))
        wheel = 2

    def speific_usgae(self):
        super().general_use() # this can also be called inside method . Of parent class
        print("Specific use Motorcycle")


#c = Car()
#c.speific_usgae()
#c.general_usage()

c = Motorcycle()
c.speific_usgae()

print(isinstance(c,Motorcycle)) # inbuilt python function to check if object is instance of the class
print(issubclass(Car,Motorcycle)) # in buit function to check if one class is a subclass of other

#https://www.youtube.com/watch?v=Z7D9yv21tig&list=PLeo1K3hjS3uv5U-Lmlnucd7gqF-3ehIh0&index=20