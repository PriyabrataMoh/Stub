class A:
    name = "ram"
    def __init__(self):
        print("in A")

    def work(self):
        print("programmer")


class B(A):
    def __init__(self):
        print("in B")

    def work(self):
        print("Painter")
        super().work() # to call parent class Method
        super().__init__() # to call parent class constructor
        print(super().name) # to call parent class instance variable

        #Can also be called as
        # print(A.name)
        # A.work(self)
        # A.__init__(self)

b = B()
b.work()
